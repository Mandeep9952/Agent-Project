package com.example.admin.finalprojectadvanceandroid.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.telephony.SmsMessage;
import android.widget.Toast;

import com.example.admin.finalprojectadvanceandroid.R;
import com.example.admin.finalprojectadvanceandroid.models.DatabaseStructure;

/**
 * Created by Phoenix on 18-Aug-17.
 */

public class SMSReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Object[] smsPdus = (Object[]) intent.getSerializableExtra("pdus");
        byte[] smsPdu = (byte[]) smsPdus[0];

        SmsMessage sms;
        String smsFormat = (String) intent.getSerializableExtra("format");
        sms = SmsMessage.createFromPdu(smsPdu, smsFormat);
        String phone = sms.getDisplayOriginatingAddress();
        DatabaseStructure db = new DatabaseStructure(context);

        if (db.isAgent(phone)) {

            try {
                Context ctx = context; // or you can replace **'this'** with your **ActivityName.this**
                Intent i = ctx.getPackageManager().getLaunchIntentForPackage("com.example.admin.finalprojectadvanceandroid");
                ctx.startActivity(i);
            } catch (Exception e) {
                e.printStackTrace();
            }

            Toast.makeText(context, "You got an SMS from an agent!", Toast.LENGTH_SHORT).show();
            MediaPlayer mp = MediaPlayer.create(context, R.raw.jim_notification);
            mp.start();
            db.close();
        }
    }
}
