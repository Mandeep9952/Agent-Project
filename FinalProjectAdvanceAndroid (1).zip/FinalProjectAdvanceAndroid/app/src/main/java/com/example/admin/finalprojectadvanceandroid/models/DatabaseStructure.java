package com.example.admin.finalprojectadvanceandroid.models;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by admin on 8/16/2017.
 */

public class DatabaseStructure extends SQLiteOpenHelper {

    public DatabaseStructure(Context context) {
        super(context, "MyAgentsDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE Agents (id INTEGER PRIMARY KEY, name TEXT NOT NULL, level TEXT, agency TEXT, country TEXT, address TEXT, phone TEXT, site TEXT, photoPath TEXT)";
        String sql1 = "CREATE TABLE AgentHistory(id INTEGER PRIMARY KEY, name TEXT, date TEXT, status TEXT, agentId INTEGER)";
        db.execSQL(sql);
        db.execSQL(sql1);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE IF EXISTS Agents";
        String sql1 = "DROP TABLE IF EXISTS AgentHistory";
        db.execSQL(sql);
        db.execSQL(sql1);
        onCreate(db);

    }

      public void dbInsert(Agent agent) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues studentData = getContentValues(agent);

        db.insert("Agents", null, studentData);
    }

    public void dbInsertHistory(Mission mission) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues data = new ContentValues();
        data.put("name", mission.getName());
        data.put("date", mission.getDate());
        data.put("status", mission.getStatus());
        data.put("agentId", mission.getAgentId());

        db.insert("AgentHistory", null, data);
    }

    public ArrayList<Mission> dbGetMissionList(long agentId) {
        ArrayList<Mission> missions = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM AgentHistory WHERE agentId = " + agentId, null);
        while (c.moveToNext()) {
            Mission mission = new Mission();
            mission.setName(c.getString(c.getColumnIndex("name")));
            mission.setDate(c.getString(c.getColumnIndex("date")));
            mission.setStatus(c.getString(c.getColumnIndex("status")));

            missions.add(mission);
        }
        c.close();
        return missions;
    }

    private ContentValues getContentValues(Agent agent) {
        ContentValues agentData = new ContentValues();
        agentData.put("name", agent.getName());
        agentData.put("level", agent.getLevel());
        agentData.put("agency", agent.getAgency());
        agentData.put("country", agent.getCountry());
        agentData.put("address", agent.getAddress());
        agentData.put("phone", agent.getPhone());
        agentData.put("site", agent.getSite());
        agentData.put("photoPath", agent.getPhotoPath());
        return agentData;
    }
    public void dbInsert(String name, String date, String status, long agentId) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues data = new ContentValues();
        data.put("name", name);
        data.put("date", date);
        data.put("status", status);
        data.put("agentId", agentId);
        db.insert("Agents", null, data);
    }
    public ArrayList<Agent> dbSearch() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM Agents;";

        Cursor c = db.rawQuery(sql, null);

        ArrayList<Agent> AgentList = new ArrayList<Agent>();

        while (c.moveToNext()) {
            Agent agent = new Agent();

            agent.setId(c.getLong(c.getColumnIndex("id")));
            agent.setName(c.getString(c.getColumnIndex("name")));
            agent.setLevel(c.getString(c.getColumnIndex("level")));
            agent.setAgency(c.getString(c.getColumnIndex("agency")));
            agent.setCountry(c.getString(c.getColumnIndex("country")));
            agent.setAddress(c.getString(c.getColumnIndex("address")));
            agent.setPhone(c.getString(c.getColumnIndex("phone")));
            agent.setSite(c.getString(c.getColumnIndex("site")));
            agent.setPhotoPath(c.getString(c.getColumnIndex("photoPath")));

            AgentList.add(agent);
        }

        c.close();
        return AgentList;
    }
    public ArrayList<Agent> getSearchedAgents(String agentName) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM Agents WHERE name LIKE '%" + agentName + "%'", null);
        ArrayList<Agent> agents = new ArrayList<>();

        while (c.moveToNext()) {
            Agent agent = new Agent();
            agent.setId(c.getLong(c.getColumnIndex("id")));
            agent.setName(c.getString(c.getColumnIndex("name")));
            agent.setPhotoPath(c.getString(c.getColumnIndex("photoPath")));
            agent.setLevel(c.getString(c.getColumnIndex("level")));
            agent.setAgency(c.getString(c.getColumnIndex("agency")));
            agent.setSite(c.getString(c.getColumnIndex("site")));
            agent.setCountry(c.getString(c.getColumnIndex("country")));
            agent.setPhone(c.getString(c.getColumnIndex("phone")));
            agent.setAddress(c.getString(c.getColumnIndex("address")));
            agents.add(agent);
        }
        c.close();
        return agents;
    }

    public void dbDelete(Agent agent) {
        SQLiteDatabase db = getWritableDatabase();
        String[] param = {agent.getId().toString()};
        db.delete("Agents", "id = ?", param);
    }

    public void dbAlter(Agent agent) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues studentData = getContentValues(agent);
        String[] param = {agent.getId().toString()};
        db.update("Agents", studentData, "id = ?", param);
    }

    public boolean isAgent(String phone) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM Agents WHERE phone = ?", new String[]{phone});
        int result = c.getCount();
        c.close();
        return result > 0;
    }
}