package com.example.admin.finalprojectadvanceandroid.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.admin.finalprojectadvanceandroid.R;
import com.example.admin.finalprojectadvanceandroid.models.Mission;

import java.util.ArrayList;

/**
 * Created by admin on 8/17/2017.
 */

public class AgentHistoryListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Mission> missions;

    public AgentHistoryListAdapter(Context context, ArrayList<Mission> missions) {
        this.context = context;
        this.missions = missions;
    }

    @Override
    public int getCount() {
        return missions.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;

        if (view == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            view = inflater.inflate(R.layout.agent_history_row, parent, false);
            TextView nameText = (TextView) view.findViewById(R.id.text_mission_name);
            TextView dateText = (TextView) view.findViewById(R.id.text_mission_date);
            TextView statusText = (TextView) view.findViewById(R.id.text_mission_status);
            String name, date, status;
            nameText.setText(missions.get(position).getName());
            dateText.setText(missions.get(position).getDate());
            statusText.setText(missions.get(position).getStatus());
        }
        return view;
    }
}
