package com.example.admin.finalprojectadvanceandroid.models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.admin.finalprojectadvanceandroid.AddActivity;

/**
 * Created by admin on 8/16/2017.
 */
import com.example.admin.finalprojectadvanceandroid.R;

public class FormHelper {

    private final EditText fieldName;
    private final EditText fieldLevel;
    private final EditText fieldAgency;
    private final EditText fieldCountry;
    private final EditText fieldAddress;
    private final EditText fieldPhone;
    private final EditText fieldSite;
    private final ImageView fieldPhoto;
    private Agent agent;

    public FormHelper(AddActivity activity) {
        fieldName =(EditText) activity.findViewById(R.id.form_name);
        fieldLevel = (EditText) activity.findViewById(R.id.form_level);
        fieldAgency = (EditText) activity.findViewById(R.id.form_agency);
        fieldCountry = (EditText) activity.findViewById(R.id.form_country);
        fieldAddress = (EditText) activity.findViewById(R.id.form_address);
        fieldPhone = (EditText) activity.findViewById(R.id.form_phone);
        fieldSite = (EditText) activity.findViewById(R.id.form_site);
        fieldPhoto = (ImageView) activity.findViewById(R.id.form_photo);

        agent = new Agent();
    }

    public Agent helperFormGetterSetter() {
        agent.setName(fieldName.getText().toString());
        agent.setLevel(fieldLevel.getText().toString());
        agent.setAgency(fieldAgency.getText().toString());
        agent.setCountry(fieldCountry.getText().toString());
        agent.setAddress(fieldAddress.getText().toString());
        agent.setPhone(fieldPhone.getText().toString());
        agent.setSite(fieldSite.getText().toString());
        agent.setPhotoPath((String) fieldPhoto.getTag());

        return agent;
    }

    public void fillForm(Agent agent) {
        fieldName.setText(agent.getName());
        fieldLevel.setText(agent.getLevel());
        fieldAgency.setText(agent.getAgency());
        fieldCountry.setText(agent.getCountry());
        fieldAddress.setText(agent.getAddress());
        fieldPhone.setText(agent.getPhone());
        fieldSite.setText(agent.getSite());
        loadImage(agent.getPhotoPath());

        this.agent = agent;
    }
    public void loadImage(String dirAppPhoto){
        if (dirAppPhoto != null){

            Bitmap bitmap = BitmapFactory.decodeFile(dirAppPhoto);
            Bitmap lowdefbitmap = Bitmap.createScaledBitmap(bitmap, 300, 300, true);
            fieldPhoto.setImageBitmap(lowdefbitmap);
            fieldPhoto.setScaleType((ImageView.ScaleType.FIT_XY));
            fieldPhoto.setTag(dirAppPhoto);
        }
    }
}