package com.example.admin.finalprojectadvanceandroid;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.finalprojectadvanceandroid.models.Agent;
import com.example.admin.finalprojectadvanceandroid.models.DatabaseStructure;
import com.example.admin.finalprojectadvanceandroid.models.FormHelper;

public class AgentProfile extends AppCompatActivity {
    private TextView profileName, profileLevel, profileAgency, profileCountry, profileAddress, profilePhone, profileSite;
    private ImageButton btnWeb, btnCall, btnLocation, btnHistory, btnSMS, btnCamera;
    private ImageView profilePhoto;
    private Agent agent;
    private  final int REQUEST_CODE = 1;
//    private FormHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_profile);
        setTitle("Agent Profile");

        profileName = (TextView) findViewById(R.id.profile_name);
        profileAddress = (TextView) findViewById(R.id.profile_address);
        profileAgency = (TextView) findViewById(R.id.profile_agency);
        profileCountry = (TextView) findViewById(R.id.profile_country);
        profilePhone = (TextView) findViewById(R.id.profile_phone);
        profileLevel = (TextView) findViewById(R.id.profile_level);
        profileSite = (TextView) findViewById(R.id.profile_site);

        profilePhoto = (ImageView) findViewById(R.id.profile_photo);

        btnWeb = (ImageButton) findViewById(R.id.btn_web);
        btnCall = (ImageButton) findViewById(R.id.btn_call);
        btnLocation = (ImageButton) findViewById(R.id.btn_location);
        btnHistory = (ImageButton) findViewById(R.id.btn_history);
        btnSMS = (ImageButton) findViewById(R.id.btn_sms);
        btnCamera = (ImageButton) findViewById(R.id.btn_camera);

        Intent intent = getIntent();
        agent = (Agent) intent.getSerializableExtra("agent");

        profileName.setText("Name: " + agent.getName());
        profileAddress.setText("Address: " + agent.getAddress());
        profileAgency.setText("Agency: " + agent.getAgency());
        profileCountry.setText("Country: " + agent.getCountry());
        profilePhone.setText("Phone: " + agent.getPhone());
        profileSite.setText("Site: " + agent.getSite());
        profileLevel.setText("Level:  " + agent.getLevel());
        loadImage(agent.getPhotoPath());

        btnWeb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSite = new Intent(Intent.ACTION_VIEW);

                String site = agent.getSite();

                if (!site.startsWith("http://")) {
                    site = "http://" + site;
                }

                intentSite.setData(Uri.parse(site));
                startActivity(intentSite);
            }
        });

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(ActivityCompat.checkSelfPermission(AgentProfile.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(AgentProfile.this, new String[]{Manifest.permission.CALL_PHONE}, 123);
                }
                else{
                    Intent itemCALL = new Intent(Intent.ACTION_CALL);
                    itemCALL.setData(Uri.parse("tel:" + agent.getPhone()));
                    startActivity(itemCALL);
                }
            }
        });

        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentMAP = new Intent(Intent.ACTION_VIEW);
                intentMAP.setData(Uri.parse("geo:0,0?q=" + agent.getAddress()));
                startActivity(intentMAP);

            }
        });

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AgentProfile.this, AgentHistoryList.class);
                intent.putExtra("agentId", agent.getId());
                startActivity(intent);
            }
        });

        btnSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSMS = new Intent(Intent.ACTION_VIEW);
                intentSMS.setData(Uri.parse("sms:" + agent.getPhone()));
                startActivity(intentSMS);
            }
        });

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AgentProfile.this, MissionUpdate.class);
                intent.putExtra("agentId", agent.getId());
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.edit, menu);

        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.menu_form_edit:
                Intent goToIntentForEditind = new Intent(AgentProfile.this, AddActivity.class);
                goToIntentForEditind.putExtra("agent", agent);
                startActivityForResult(goToIntentForEditind, REQUEST_CODE);
                break;

            case R.id.menu_form_add:
                Intent goToIntentAddHistory = new Intent(AgentProfile.this, AddAgentHistoryActivity.class);
                goToIntentAddHistory.putExtra("agentName",agent.getName());
                startActivity(goToIntentAddHistory);
                break;

        }
        return super.onOptionsItemSelected(item);
    }


    public void loadImage(String dirAppPhoto){
        if (dirAppPhoto != null){

            Bitmap bitmap = BitmapFactory.decodeFile(dirAppPhoto);
            Bitmap lowdefbitmap = Bitmap.createScaledBitmap(bitmap, 300, 300, true);
            profilePhoto.setImageBitmap(lowdefbitmap);
            profilePhoto.setScaleType((ImageView.ScaleType.FIT_XY));
            profilePhoto.setTag(dirAppPhoto);
        }
    }


}
