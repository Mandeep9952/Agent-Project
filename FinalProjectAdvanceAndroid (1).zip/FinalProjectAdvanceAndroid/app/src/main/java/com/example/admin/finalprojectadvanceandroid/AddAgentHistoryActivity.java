package com.example.admin.finalprojectadvanceandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.finalprojectadvanceandroid.models.Agent;
import com.example.admin.finalprojectadvanceandroid.models.DatabaseStructure;
import com.example.admin.finalprojectadvanceandroid.models.FormHelper;
import com.example.admin.finalprojectadvanceandroid.models.Mission;

import static android.R.attr.name;

public class AddAgentHistoryActivity extends AppCompatActivity {

    EditText editHistoryName, editHistoryDate, editHistoryStatus;
    Button addHistory;
    DatabaseStructure databaseStructure ;

    String name, date, status;
    long agentId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_agent_history);
        setTitle("Add Agent  History");

        editHistoryName = (EditText) findViewById(R.id.edit_history_name);
        editHistoryDate = (EditText) findViewById(R.id.edit_history_date);
        editHistoryStatus = (EditText) findViewById(R.id.edit_history_status);
        addHistory = (Button) findViewById(R.id.add_history);

        agentId = getIntent().getLongExtra("agentId", -1);

        addHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editHistoryName.getText().toString();
                String date = editHistoryDate.getText().toString();
                String status = editHistoryStatus.getText().toString();

                if (name != null && date != null && status != null) {
                    databaseStructure = new DatabaseStructure(AddAgentHistoryActivity.this);
                    Mission mission = new Mission();
                    mission.setName(name);
                    mission.setDate(date);
                    mission.setStatus(status);
                    mission.setAgentId(agentId);
                    databaseStructure.dbInsertHistory(mission);
                    databaseStructure.close();
                    Toast.makeText(AddAgentHistoryActivity.this, "Mission history added successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(AddAgentHistoryActivity.this, "Please provide values for all fields!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
