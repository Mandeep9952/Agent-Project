package com.example.admin.finalprojectadvanceandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.admin.finalprojectadvanceandroid.adapters.AgentListAdapter;
import com.example.admin.finalprojectadvanceandroid.models.Agent;
import com.example.admin.finalprojectadvanceandroid.models.DatabaseStructure;

import java.util.ArrayList;

public class AgentList extends AppCompatActivity {
    ListView agentListView;
    String  searchStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_list);
        setTitle("Agents List");

        agentListView =(ListView) findViewById(R.id.agent_list);

        DatabaseStructure db = new DatabaseStructure(AgentList.this);
        AgentListAdapter adapter = new AgentListAdapter(AgentList.this, db.dbSearch());
        agentListView.setAdapter(adapter);

        agentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Agent agent = (Agent) agentListView.getItemAtPosition(position);
                Intent intent = new Intent(AgentList.this, AgentProfile.class);
                intent.putExtra("agent", agent);
                startActivity(intent);
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        searchStr = intent.getStringExtra("searchStr");
        DatabaseStructure db = new DatabaseStructure(this);
        if (searchStr == null) {
            AgentListAdapter adapter = new AgentListAdapter(this, db.dbSearch());
            agentListView.setAdapter(adapter);
        } else {
            AgentListAdapter adapter = new AgentListAdapter(this, db.getSearchedAgents(searchStr));
            agentListView.setAdapter(adapter);
        }
    }
}
