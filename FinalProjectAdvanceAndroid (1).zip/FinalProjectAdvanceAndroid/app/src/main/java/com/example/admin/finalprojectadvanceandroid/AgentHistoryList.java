package com.example.admin.finalprojectadvanceandroid;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.MenuItemHoverListener;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.admin.finalprojectadvanceandroid.adapters.AgentHistoryListAdapter;
import com.example.admin.finalprojectadvanceandroid.models.DatabaseStructure;
import com.example.admin.finalprojectadvanceandroid.models.Mission;

public class AgentHistoryList extends AppCompatActivity {

    private ListView missionList;
    private long agentId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_history_list);
        setTitle("Agent History");

        missionList = (ListView) findViewById(R.id.missionListView);

        agentId = getIntent().getLongExtra("agentId", -1);
        Button addBtn = (Button) findViewById(R.id.buttonAddMission);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AgentHistoryList.this, AddAgentHistoryActivity.class);
                intent.putExtra("agentId", agentId);
                startActivity(intent);
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        Mission mission = new Mission();
        DatabaseStructure db = new DatabaseStructure(AgentHistoryList.this);
        AgentHistoryListAdapter adapter = new AgentHistoryListAdapter(AgentHistoryList.this, db.dbGetMissionList(agentId));
        missionList.setAdapter(adapter);
    }
}
