package com.example.admin.finalprojectadvanceandroid;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AfterLoginFirstPage extends AppCompatActivity {

    Button btnList, btnAddUser, btnSearch;
    private String m_Text = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_login_first_page);
        setTitle("Main Menu");

        if (ContextCompat.checkSelfPermission(AfterLoginFirstPage.this,
                Manifest.permission.RECEIVE_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(AfterLoginFirstPage.this,
                    new String[]{Manifest.permission.RECEIVE_SMS}, 1);
        }
        btnList = (Button) findViewById(R.id.btn_list);
        btnSearch = (Button) findViewById(R.id.btn_search);
        btnAddUser = (Button) findViewById(R.id.btn_add_user);

        btnAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AfterLoginFirstPage.this, AddActivity.class);
                startActivity(intent);
            }
        });
        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AfterLoginFirstPage.this, AgentList.class);
                startActivity(intent);
            }
        });
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder alert = new AlertDialog.Builder(AfterLoginFirstPage.this);
                final EditText editText = new EditText(AfterLoginFirstPage.this);
                alert.setTitle("Enter name of the agent you want to search.");
                alert.setView(editText);
                alert.setCancelable(false);
                alert.setPositiveButton("Search", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String searchStr = editText.getText().toString();
                        if (!searchStr.isEmpty()) {
                            Intent goToAgentListIntent = new Intent(AfterLoginFirstPage.this, AgentList.class);
                            goToAgentListIntent.putExtra("searchStr", searchStr);
                            dialog.dismiss();
                            startActivity(goToAgentListIntent);
                        } else {
                            Toast.makeText(AfterLoginFirstPage.this, "Please provide a name to search", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                alert.show();
            }
    });
    }
}
