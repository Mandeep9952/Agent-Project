package com.example.admin.finalprojectadvanceandroid.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.finalprojectadvanceandroid.R;
import com.example.admin.finalprojectadvanceandroid.models.Agent;

import java.util.ArrayList;

/**
 * Created by admin on 8/16/2017.
 */

public class AgentListAdapter extends BaseAdapter {
    private static LayoutInflater inflater = null;
    private ArrayList<Agent> agents;
    ImageView agentImageView;
    TextView agentNameTextView, agentLevelTextView;

    public AgentListAdapter(Context context, ArrayList<Agent> agents) {
        this.agents = agents;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return agents.size();
    }

    @Override
    public Object getItem(int position) {
        return agents.get(position);
    }

    @Override
    public long getItemId(int position) {
        return agents.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;

        if (convertView == null){
            view = inflater.inflate(R.layout.agent_list_row, null);
            agentImageView = (ImageView) view.findViewById(R.id.agent_ImageView);
            agentNameTextView = (TextView) view.findViewById(R.id.agent_name);
            agentLevelTextView = (TextView) view.findViewById(R.id.agent_level);
            Agent agent = agents.get(position);
            agentNameTextView.setText("Name: " + agent.getName());
            agentLevelTextView.setText("Level: " + agent.getLevel());
            loadImage(agent.getPhotoPath());
        }
        return view;
    }

    public void loadImage(String dirAppPhoto){
        if (dirAppPhoto != null){

            Bitmap bitmap = BitmapFactory.decodeFile(dirAppPhoto);
            Bitmap lowdefbitmap = Bitmap.createScaledBitmap(bitmap, 300, 300, true);
            agentImageView.setImageBitmap(lowdefbitmap);
            agentImageView.setScaleType((ImageView.ScaleType.FIT_XY));
            agentImageView.setTag(dirAppPhoto);
        }
    }
}
